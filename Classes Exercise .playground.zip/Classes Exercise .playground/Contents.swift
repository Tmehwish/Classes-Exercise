import UIKit

class dreamCar {
    var  carHorsepower: String = "400"
    var carColor: String = "Red"
    var carMaterial: String = "Leather"
    var carBrand: String = "Mercedes"

// Defining Behaviors
var carAttributes = dreamCar
    
    func dreamcar(carHorsepower: String, carColor: String, carMaterial: String, carBrand: String)
    -> String {
        print("My dream car would have a \(carHorsepower) becuase I am confortable with that speed. I like \(carColor) cars. I want a \(carBrand) with \(carMaterial) seats for my dream car. ")
        
}
}

